int c(int x, int y, int z){
	int a[20];
	
}

int main(void){}