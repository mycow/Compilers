/* hello.c */

int printf(), r(), nattyBitch();

int c[900];

int h;

int suhBish(int a, int i){
	a = 5;
	return a;
}

int main(void)
{
	int x, y;
	int z[10];
	x = 1;
	y = 2;

    printf("hello world\n");
}
